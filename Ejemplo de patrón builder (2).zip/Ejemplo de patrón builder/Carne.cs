class Carne:Icarne{
    
    public string cantidadcarne(){

        return "una carne";
    }
}