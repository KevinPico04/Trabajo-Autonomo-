interface Isalsa{
    string tiposalsa();

}
