class Director{


    public void construye(Ibuilder pConstructor){

        pConstructor.ponercarnes();
        pConstructor.ponersalsas();
        pConstructor.poneradicionales();
    }
}