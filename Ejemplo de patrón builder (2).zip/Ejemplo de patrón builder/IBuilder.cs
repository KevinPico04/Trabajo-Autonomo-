interface Ibuilder{

    void ponercarnes();
    void ponersalsas();
    void poneradicionales();

}