﻿internal class Program
{
    private static void Main(string[] args)
    {
        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
        Director miDirector = new Director();

        // Construimos una casa grande
        hamburguesasimple hs = new hamburguesasimple();
        miDirector.construye(hs);

        //Obtenemos la casa
        producto hamburguesa1 = hs.obtenerproducto();
        hamburguesa1.Mostrarproducto();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");
        

        //construimos una casa mediana
        hamburguesacompleta hc = new hamburguesacompleta();
        miDirector.construye(hc);

        //Obtenemos la casa
        producto hamburguesa2 = hc.obtenerproducto();
        hamburguesa2.Mostrarproducto();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");


        //construimos una casa pequeña 
        hamburguesaespecial he = new hamburguesaespecial();
        miDirector.construye(he);

        //Obtenemos la casa
        producto hamburguesa3 = he.obtenerproducto();
        hamburguesa3.Mostrarproducto();

        Console.WriteLine("----------------------------------------------------------------------------------------------------------------------");

        


    }
}