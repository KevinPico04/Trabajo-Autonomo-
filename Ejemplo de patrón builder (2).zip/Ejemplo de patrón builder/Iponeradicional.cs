interface Iadicional{

    string tipoadicional();
}