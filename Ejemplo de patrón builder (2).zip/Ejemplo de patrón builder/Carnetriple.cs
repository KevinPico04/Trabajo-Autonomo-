class Carnetriple:Icarne{
    
    public string cantidadcarne(){

        return "Triple carne";
    }
}