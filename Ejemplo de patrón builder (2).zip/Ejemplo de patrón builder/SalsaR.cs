class SalsaR:Isalsa{

    public string tiposalsa(){
        
        return "Salsa ranchera";
    }
}