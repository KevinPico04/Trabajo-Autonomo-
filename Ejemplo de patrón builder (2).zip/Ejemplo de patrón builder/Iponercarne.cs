interface Icarne{

    string cantidadcarne();
}