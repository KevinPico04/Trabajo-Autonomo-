class salsaQ:Isalsa{

    public string tiposalsa(){
        return "Salsa de queso";
    }
}