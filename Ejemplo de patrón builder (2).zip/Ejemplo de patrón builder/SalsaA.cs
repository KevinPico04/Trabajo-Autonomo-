class SalsaA:Isalsa{

    public string tiposalsa(){
        return "salsa agria";
    }
}