class hamburguesasimple:Ibuilder{

    private producto  h1 = new producto();

    public void ponercarnes(){
        h1.Colocarcarnes(new Carne());
    }

    public void poneradicionales(){
        h1.Colocaradicional(new Apapas());
        
    }
    public void ponersalsas(){
        h1.Colocarsalsa(new salsaQ());

    }
    public producto obtenerproducto(){
        return h1;
    }
}
    