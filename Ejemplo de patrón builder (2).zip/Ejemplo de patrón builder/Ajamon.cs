class Ajamon:Iadicional{

    public string tipoadicional(){
        return "Jamón";
    }
}