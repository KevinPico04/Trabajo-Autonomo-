class hamburguesaespecial:Ibuilder{

    private producto h3= new producto();

    public void ponercarnes()
    {
        h3.Colocarcarnes(new Carnetriple());
    }
    public void poneradicionales()
    {
        h3.Colocaradicional(new Atocino());
        
    }
    public void ponersalsas()
    {
        h3.Colocarsalsa(new SalsaA());
    }
    public producto obtenerproducto(){
        return h3;
    }
}
    