class Carnedoble:Icarne{
    
    public string cantidadcarne(){

        return "Doble carne";
    }
}