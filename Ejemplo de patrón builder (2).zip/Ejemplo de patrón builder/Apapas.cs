class Apapas:Iadicional{

    public string tipoadicional(){
        return "Papas";
    }
    
}