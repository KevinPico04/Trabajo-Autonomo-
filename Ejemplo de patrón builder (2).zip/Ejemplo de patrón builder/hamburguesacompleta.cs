class hamburguesacompleta:Ibuilder{

    private producto h2=new producto ();

    public void ponercarnes()
    {
       h2.Colocarcarnes(new Carnedoble());
    }
    public void poneradicionales()
    {
        h2.Colocaradicional(new Ajamon());
        
    }
    public void ponersalsas()
    {
        h2.Colocarsalsa(new SalsaR());
    }
    public producto obtenerproducto(){
        return h2;
    }
    
}