class Atocino:Iadicional{

    public string tipoadicional(){
        return "Tocino";
    }
   
}