class producto
{
    
    private Icarne carne;
    private  Isalsa salsa;
    private  Iadicional adicional;
    public void Colocarcarnes(Icarne pCarnes){
        carne = pCarnes;
        Console.WriteLine("-Se puso:  {0}", carne.cantidadcarne());

    }

    public void Colocarsalsa(Isalsa pSalsas){
        salsa=pSalsas;
        Console.WriteLine("-Se puso:  {0} ", salsa.tiposalsa());

    }

    public void Colocaradicional(Iadicional  pAdicional){
        adicional = pAdicional;
         Console.WriteLine("-Se puso:  {0} ", adicional.tipoadicional());
    }

    

    public void Mostrarproducto(){

        Console.WriteLine("Tu hamburguesa tiene: {0}, {1}, {2}", carne.cantidadcarne(), salsa.tiposalsa(), adicional.tipoadicional());
    }
}

    